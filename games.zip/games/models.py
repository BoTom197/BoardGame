from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class BoardGame(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title

class Gamer(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    borrowed_games = models.ManyToManyField(BoardGame, through='Loan')

    def __str__(self):
        return self.user.username

class Loan(models.Model):
    gamer = models.ForeignKey(Gamer, on_delete=models.CASCADE)
    game = models.ForeignKey(BoardGame, on_delete=models.CASCADE)
    borrowed_at = models.DateTimeField(auto_now_add=True)
    returned_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.gamer} borrowed {self.game}"
    