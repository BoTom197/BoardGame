from datetime import timezone
from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import BoardGame, Loan, Gamer
from django.contrib.auth.decorators import login_required
from django.contrib import messages

# Trang chính
def index(request):
    return render(request, 'games/index.html')

# Danh sách trò chơi
def game_list(request):
    games = BoardGame.objects.all()
    return render(request, 'games/game_list.html', {'games': games})

# Thêm trò chơi
@login_required
def add_game(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        description = request.POST.get('description')
        game = BoardGame(title=title, description=description)
        game.save()
        messages.success(request, 'Game added successfully!')
        return redirect('game_list')
    return render(request, 'games/add_game.html')

# Mượn trò chơi
@login_required
def borrow_game(request, game_id):
    game = get_object_or_404(BoardGame, pk=game_id)
    gamer = get_object_or_404(Gamer, user=request.user)

    # Kiểm tra số lượng trò chơi đã mượn
    if gamer.borrowed_games.count() < 3:
        Loan.objects.create(gamer=gamer, game=game)
        messages.success(request, f'You borrowed {game.title}!')
    else:
        messages.error(request, 'You cannot borrow more than 3 games at the same time.')

    return redirect('game_list')

# Trả lại trò chơi
@login_required
def return_game(request, loan_id):
    loan = get_object_or_404(Loan, pk=loan_id)
    loan.returned_at = timezone.now()
    loan.save()
    messages.success(request, 'Game returned successfully!')
    return redirect('game_list')

