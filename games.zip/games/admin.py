from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import BoardGame, Gamer, Loan

admin.site.register(BoardGame)
admin.site.register(Gamer)
admin.site.register(Loan)
