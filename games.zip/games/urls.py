from django.urls import path
from . import views
from django.contrib import admin
from django.urls import include, path
from django.views.generic import TemplateView  # Thêm dòng này

urlpatterns = [
    path('', views.index, name='index'),
    path('games/', views.game_list, name='game_list'),
    path('games/add/', views.add_game, name='add_game'),
    path('games/borrow/<int:game_id>/', views.borrow_game, name='borrow_game'),
    path('games/return/<int:loan_id>/', views.return_game, name='return_game'),

]
urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),  # Include auth URLs
    path('', TemplateView.as_view(template_name='home.html'), name='home'),  # Home page
    path('', include('games.urls')),
]
